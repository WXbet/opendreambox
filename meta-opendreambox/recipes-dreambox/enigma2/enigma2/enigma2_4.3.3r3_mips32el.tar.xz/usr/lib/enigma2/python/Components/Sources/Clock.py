from Components.Element import cached
from enigma import eTimer
from time import time as getTime

from Source import Source

class Clock(Source):
	def __init__(self):
		Source.__init__(self)
		self.clock_timer = eTimer()
		self.clock_timer_conn = self.clock_timer.timeout.connect(self.poll)

	@cached
	def getClock(self):
		return getTime()

	time = property(getClock)

	def poll(self):
		self.changed((self.CHANGED_POLL,))

	def doSuspend(self, suspended):
		if suspended:
			self.clock_timer.stop()
		else:
			self.clock_timer.start(1000)
			self.poll()

	def destroy(self):
		self.clock_timer_conn = None
		Source.destroy(self)
